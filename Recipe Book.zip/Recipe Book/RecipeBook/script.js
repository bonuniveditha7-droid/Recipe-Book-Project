// ====== My Recipe Book Script ======

// Get DOM elements
const addBtn = document.getElementById("addRecipe");
const recipeList = document.getElementById("recipeList");
const searchInput = document.getElementById("searchInput");

// Modal elements
const modal = document.getElementById("recipeModal");
const closeBtn = document.querySelector(".close");
const modalTitle = document.getElementById("modalTitle");
const modalImage = document.getElementById("modalImage");
const modalIngredients = document.getElementById("modalIngredients");
const modalSteps = document.getElementById("modalSteps");

// ====== Load saved recipes from localStorage ======
let recipes = JSON.parse(localStorage.getItem("recipes")) || [];

// ====== Display all recipes ======
function displayRecipes(filteredList = recipes) {
  recipeList.innerHTML = "";

  if (filteredList.length === 0) {
    recipeList.innerHTML = "<p>No recipes found. Add one above!</p>";
    return;
  }

  filteredList.forEach((recipe, index) => {
    const card = document.createElement("div");
    card.classList.add("recipe-card");
    card.innerHTML = `
      <img src="${recipe.image || 'https://via.placeholder.com/300x160?text=No+Image'}" alt="${recipe.name}">
      <h3>${recipe.name}</h3>
    `;
    card.addEventListener("click", () => openModal(index));
    recipeList.appendChild(card);
  });
}

// ====== Add new recipe ======
addBtn.addEventListener("click", () => {
  const name = document.getElementById("recipeName").value.trim();
  const ingredients = document.getElementById("ingredients").value.trim();
  const steps = document.getElementById("steps").value.trim();
  const imageFile = document.getElementById("imageUpload").files[0];

  if (!name || !ingredients || !steps) {
    alert("Please fill all fields before adding a recipe!");
    return;
  }

  const newRecipe = {
    name,
    ingredients,
    steps,
    image: ""
  };

  if (imageFile) {
    const reader = new FileReader();
    reader.onload = function (e) {
      newRecipe.image = e.target.result;
      recipes.push(newRecipe);
      saveAndDisplay();
    };
    reader.readAsDataURL(imageFile);
  } else {
    recipes.push(newRecipe);
    saveAndDisplay();
  }

  document.getElementById("recipeName").value = "";
  document.getElementById("ingredients").value = "";
  document.getElementById("steps").value = "";
  document.getElementById("imageUpload").value = "";
});

// ====== Save recipes to localStorage and refresh list ======
function saveAndDisplay() {
  localStorage.setItem("recipes", JSON.stringify(recipes));
  displayRecipes();
  updateNavbarIcon();
}

// ====== Search recipes ======
searchInput.addEventListener("input", () => {
  const searchTerm = searchInput.value.toLowerCase();
  const filtered = recipes.filter(
    (r) =>
      r.name.toLowerCase().includes(searchTerm) ||
      r.ingredients.toLowerCase().includes(searchTerm)
  );
  displayRecipes(filtered);
});

// ====== Open Modal ======
function openModal(index) {
  const recipe = recipes[index];
  modal.style.display = "block";
  modalTitle.textContent = recipe.name;
  modalImage.src = recipe.image || "https://via.placeholder.com/400x250?text=No+Image";
  modalIngredients.textContent = recipe.ingredients;
  modalSteps.textContent = recipe.steps;
}

// ====== Close Modal ======
closeBtn.onclick = function () {
  modal.style.display = "none";
};
window.onclick = function (event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
};

// ====== Navbar Icon Update ======
function updateNavbarIcon() {
  const countEl = document.getElementById("recipeCount");
  if (!countEl) return;
  countEl.textContent = recipes.length > 0 ? recipes.length : "";
}

// ====== Initial Display ======
displayRecipes();
updateNavbarIcon();
