Recipe Book Web Application – Internship Submission

Project Overview
This is a responsive recipe book web application built using HTML, CSS, and JavaScript. It allows users to add, view, and search for recipes with ingredients, preparation steps, and images. Designed as part of my internship task to demonstrate front-end development and local data storage capabilities.

Important Instructions

> Please extract the ZIP file before opening `index.html` in your browser.  
> Opening the file directly from inside the ZIP (temporary folder) may prevent images and styles from loading correctly.

To View the Website Properly:
1. Right-click the ZIP file and select "Extract All..."
2. Open the extracted folder
3. Right-click `index.html` → Open with → Chrome, Edge, or Firefox

Features
- Add recipes with name, ingredients, steps, and image
- View all saved recipes in a clean card-style layout
- Search recipes by name or ingredient
- Data persistence using browser localStorage
- Responsive design for desktop and mobile
- Separate pages for Add, View, Search, and About

Technologies Used
- HTML5
- CSS3
- JavaScript (Vanilla)

Created By
Niveditha  
Tirupati, Andhra Pradesh  
MCA Student | Web Developer  
Internship Project: Unified Mentor
